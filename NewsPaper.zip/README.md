# NewsPaper
 Project for NIC
