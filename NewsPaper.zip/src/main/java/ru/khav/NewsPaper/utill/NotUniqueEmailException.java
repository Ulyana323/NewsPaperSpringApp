package ru.khav.NewsPaper.utill;

public class NotUniqueEmailException extends RuntimeException {
}
